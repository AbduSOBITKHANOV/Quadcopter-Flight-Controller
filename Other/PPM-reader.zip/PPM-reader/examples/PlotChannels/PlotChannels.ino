#include <PPMReader.h>

#define PPM_PIN 2
#define CHANNEL_AMOUNT 6
unsigned int remoteController[6];

PPMDecoder ppm(PPM_PIN, CHANNEL_AMOUNT);

void setup() {
    Serial.begin(115200);
    ppm.begin();
}

void loop() {

    if (ppm.isSignalLost()) {

        for (int i = 0; i < CHANNEL_AMOUNT; i++) remoteController[i] = (i < 4) ? 500 : 1000;

    } else if (ppm.available()) {

        for (int i = 0; i < CHANNEL_AMOUNT; i++) remoteController[i] = (i < 4) ? fminf(fmaxf(ppm.getChannelValue(i) - 1000.0, 0.0), 1000.0) : ppm.getChannelValue(i);

    }
    
    for (int i = 0; i < CHANNEL_AMOUNT; i++) {
        Serial.print(remoteController[i]);
        Serial.print("\t");
    }


    Serial.println();

    delay(50);
}

